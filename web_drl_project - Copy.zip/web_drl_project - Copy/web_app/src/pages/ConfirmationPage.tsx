import React from 'react';
import { useStore } from '../StoreContext';

export const ConfirmationPage: React.FC = () => {
  const { state, reset, setPage } = useStore();

  const handleNewOrder = () => {
    reset();
    setPage('home');
  };

  return (
    <div className="container mx-auto px-4 py-8" data-testid="confirmation-page">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8 text-center">
        <div className="mb-6">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-12 h-12 text-green-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-green-600 mb-2">Order Confirmed!</h1>
          <p className="text-gray-600">Thank you for your purchase</p>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <div className="mb-4">
            <span className="text-sm text-gray-600">Order Number</span>
            <p className="text-lg font-mono font-semibold" data-testid="order-number">
              {state.orderNumber}
            </p>
          </div>

          <div className="border-t pt-4">
            <div className="flex justify-between mb-2" data-testid="confirmation-subtotal">
              <span className="text-gray-600">Subtotal:</span>
              <span>${state.subtotal.toFixed(2)}</span>
            </div>

            {state.coupon && (
              <div className="flex justify-between mb-2 text-green-600" data-testid="confirmation-coupon">
                <span>Coupon ({state.coupon.code}):</span>
                <span>-${state.coupon.discountValue.toFixed(2)}</span>
              </div>
            )}

            <div className="flex justify-between mb-2" data-testid="confirmation-tax">
              <span className="text-gray-600">Tax:</span>
              <span>${state.tax.toFixed(2)}</span>
            </div>

            <div className="flex justify-between mb-2" data-testid="confirmation-shipping">
              <span className="text-gray-600">Shipping:</span>
              <span>{state.shipping === 0 ? 'FREE' : `$${state.shipping.toFixed(2)}`}</span>
            </div>

            <div className="border-t pt-2 mt-2">
              <div className="flex justify-between text-xl font-bold" data-testid="confirmation-total">
                <span>Total:</span>
                <span>${state.total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <p className="text-sm text-gray-600">
            A confirmation email has been sent to your email address.
          </p>

          <button
            onClick={handleNewOrder}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700"
            data-testid="new-order-button"
          >
            Start New Order
          </button>
        </div>
      </div>
    </div>
  );
};
