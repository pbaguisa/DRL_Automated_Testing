"""
Evaluate trained DRL agent on web e-commerce environment
Runs N episodes and collects detailed metrics
"""
import argparse
import os
import sys
from datetime import datetime
import csv
import numpy as np

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from envs.web.web_shop_env import WebShopEnv
from stable_baselines3 import PPO, A2C


def evaluate(
    model_path: str,
    algo: str = "ppo",
    persona: str = "shopper",
    n_episodes: int = 10,
    seed: int = 1,
    save_screenshots: bool = False
):
    """
    Evaluate trained agent
    
    Args:
        model_path: Path to trained model
        algo: Algorithm used (ppo or a2c)
        persona: Reward mode/persona
        n_episodes: Number of evaluation episodes
        seed: Random seed
        save_screenshots: Whether to save screenshots during episodes
    """
    # Load model
    if algo.lower() == "ppo":
        model = PPO.load(model_path)
    elif algo.lower() == "a2c":
        model = A2C.load(model_path)
    else:
        raise ValueError(f"Unknown algorithm: {algo}")
    
    print(f"\n{'='*60}")
    print(f"Evaluating {algo.upper()} agent")
    print(f"Model: {model_path}")
    print(f"Persona: {persona}")
    print(f"Episodes: {n_episodes}")
    print(f"Seed: {seed}")
    print(f"{'='*60}\n")
    
    # Create environment
    env = WebShopEnv(
        reward_mode=persona,
        headless=not save_screenshots,
        max_steps=50,
        seed=seed
    )
    
    # Results storage
    episode_results = []
    
    for episode in range(n_episodes):
        print(f"\nEpisode {episode + 1}/{n_episodes}")
        
        obs, info = env.reset()
        episode_reward = 0
        steps = 0
        done = False
        
        cart_operations = 0
        coupon_attempts = 0
        checkout_attempted = False
        order_completed = False
        
        while not done:
            # Get action from model
            action, _states = model.predict(obs, deterministic=True)
            
            # Track specific actions
            if action in [1, 2, 3, 4, 5, 6, 7, 8, 9]:  # Add to cart actions
                cart_operations += 1
            if action in [11, 12, 13, 14]:  # Coupon actions
                coupon_attempts += 1
            if action == 15:  # Checkout
                checkout_attempted = True
            
            # Take action
            obs, reward, terminated, truncated, info = env.step(action)
            
            episode_reward += reward
            steps += 1
            done = terminated or truncated
            
            # Take screenshot if requested
            if save_screenshots and steps % 10 == 0:
                screenshot_dir = os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "logs",
                    "screenshots",
                    f"episode_{episode + 1}"
                )
                os.makedirs(screenshot_dir, exist_ok=True)
                screenshot_path = os.path.join(screenshot_dir, f"step_{steps}.png")
                env.page.screenshot(path=screenshot_path)
        
        # Check if order was completed
        order_completed = info.get('order_complete', False)
        final_total = info.get('total', 0)
        
        # Store results
        episode_results.append({
            'episode': episode + 1,
            'total_reward': episode_reward,
            'steps': steps,
            'cart_operations': cart_operations,
            'coupon_attempts': coupon_attempts,
            'checkout_attempted': checkout_attempted,
            'order_completed': order_completed,
            'final_total': final_total,
        })
        
        print(f"  Reward: {episode_reward:.2f}")
        print(f"  Steps: {steps}")
        print(f"  Cart ops: {cart_operations}")
        print(f"  Coupon attempts: {coupon_attempts}")
        print(f"  Order completed: {order_completed}")
        print(f"  Final total: ${final_total:.2f}")
    
    # Close environment
    env.close()
    
    # Calculate statistics
    rewards = [r['total_reward'] for r in episode_results]
    steps_list = [r['steps'] for r in episode_results]
    success_rate = sum(1 for r in episode_results if r['order_completed']) / n_episodes
    
    print(f"\n{'='*60}")
    print(f"Evaluation Summary")
    print(f"{'='*60}")
    print(f"Mean reward: {np.mean(rewards):.2f} ± {np.std(rewards):.2f}")
    print(f"Mean steps: {np.mean(steps_list):.2f} ± {np.std(steps_list):.2f}")
    print(f"Success rate: {success_rate * 100:.1f}%")
    print(f"{'='*60}\n")
    
    # Save results to CSV
    log_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "logs"
    )
    os.makedirs(log_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = os.path.join(log_dir, f"eval_{algo}_{persona}_seed{seed}_{timestamp}.csv")
    
    with open(csv_path, 'w', newline='') as f:
        fieldnames = episode_results[0].keys()
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(episode_results)
    
    print(f"Results saved to: {csv_path}")
    
    # Save summary
    summary = {
        'mean_reward': float(np.mean(rewards)),
        'std_reward': float(np.std(rewards)),
        'mean_steps': float(np.mean(steps_list)),
        'std_steps': float(np.std(steps_list)),
        'success_rate': float(success_rate),
        'n_episodes': n_episodes,
    }
    
    summary_path = os.path.join(log_dir, f"eval_summary_{algo}_{persona}_seed{seed}_{timestamp}.csv")
    with open(summary_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=summary.keys())
        writer.writeheader()
        writer.writerow(summary)
    
    print(f"Summary saved to: {summary_path}")
    
    return episode_results, summary


def main():
    parser = argparse.ArgumentParser(description="Evaluate trained DRL agent on web shop environment")
    parser.add_argument('--model', type=str, required=True,
                        help='Path to trained model (without .zip extension)')
    parser.add_argument('--algo', type=str, default='ppo', choices=['ppo', 'a2c'],
                        help='Algorithm used (default: ppo)')
    parser.add_argument('--persona', type=str, default='shopper', choices=['shopper', 'validator'],
                        help='Reward mode/persona (default: shopper)')
    parser.add_argument('--episodes', type=int, default=10,
                        help='Number of evaluation episodes (default: 10)')
    parser.add_argument('--seed', type=int, default=1,
                        help='Random seed (default: 1)')
    parser.add_argument('--screenshots', action='store_true',
                        help='Save screenshots during evaluation')
    
    args = parser.parse_args()
    
    evaluate(
        model_path=args.model,
        algo=args.algo,
        persona=args.persona,
        n_episodes=args.episodes,
        seed=args.seed,
        save_screenshots=args.screenshots
    )


if __name__ == "__main__":
    main()
