import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'Gaming Laptop Pro',
    price: 1499.99,
    description: 'High-performance gaming laptop with RTX 4070, 16GB RAM, 1TB SSD',
    category: 'Laptops',
    image: 'https://via.placeholder.com/300x200/4F46E5/FFFFFF?text=Gaming+Laptop',
    stock: 15,
  },
  {
    id: 2,
    name: 'Wireless Mouse X1',
    price: 49.99,
    description: 'Ergonomic wireless mouse with precision tracking',
    category: 'Accessories',
    image: 'https://via.placeholder.com/300x200/10B981/FFFFFF?text=Wireless+Mouse',
    stock: 50,
  },
  {
    id: 3,
    name: 'Mechanical Keyboard RGB',
    price: 129.99,
    description: 'Cherry MX switches, customizable RGB lighting',
    category: 'Accessories',
    image: 'https://via.placeholder.com/300x200/F59E0B/FFFFFF?text=Keyboard',
    stock: 30,
  },
  {
    id: 4,
    name: '27" 4K Monitor',
    price: 399.99,
    description: 'Ultra HD display, 144Hz refresh rate, HDR support',
    category: 'Monitors',
    image: 'https://via.placeholder.com/300x200/EF4444/FFFFFF?text=4K+Monitor',
    stock: 20,
  },
  {
    id: 5,
    name: 'USB-C Hub Pro',
    price: 79.99,
    description: '7-in-1 USB-C hub with HDMI, Ethernet, and SD card reader',
    category: 'Accessories',
    image: 'https://via.placeholder.com/300x200/8B5CF6/FFFFFF?text=USB-C+Hub',
    stock: 40,
  },
  {
    id: 6,
    name: 'Webcam HD 1080p',
    price: 89.99,
    description: 'Full HD webcam with auto-focus and noise reduction',
    category: 'Accessories',
    image: 'https://via.placeholder.com/300x200/06B6D4/FFFFFF?text=Webcam',
    stock: 25,
  },
  {
    id: 7,
    name: 'Desktop PC Workstation',
    price: 2199.99,
    description: 'Intel i9, 32GB RAM, RTX 4080, 2TB NVMe SSD',
    category: 'Desktops',
    image: 'https://via.placeholder.com/300x200/EC4899/FFFFFF?text=Desktop+PC',
    stock: 10,
  },
  {
    id: 8,
    name: 'Portable SSD 1TB',
    price: 149.99,
    description: 'Ultra-fast portable SSD with USB 3.2 Gen 2',
    category: 'Storage',
    image: 'https://via.placeholder.com/300x200/14B8A6/FFFFFF?text=SSD',
    stock: 35,
  },
];

export const COUPONS: Record<string, number> = {
  'SAVE10': 10,
  'SAVE20': 20,
  'WELCOME15': 15,
  'HOLIDAY25': 25,
};

export const CATEGORIES = ['All', 'Laptops', 'Desktops', 'Monitors', 'Accessories', 'Storage'];

export const TAX_RATE = 0.13; // 13% tax
export const SHIPPING_THRESHOLD = 100; // Free shipping over $100
export const SHIPPING_COST = 15;
