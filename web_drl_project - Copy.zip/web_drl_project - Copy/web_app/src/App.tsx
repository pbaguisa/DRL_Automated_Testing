import React from 'react';
import { StoreProvider, useStore } from './StoreContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { TestHUD } from './components/TestHUD';
import { HomePage } from './pages/HomePage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartPage } from './pages/CartPage';
import { ConfirmationPage } from './pages/ConfirmationPage';

const AppContent: React.FC = () => {
  const { state } = useStore();

  const renderPage = () => {
    switch (state.page) {
      case 'home':
        return <HomePage />;
      case 'pdp':
        return <ProductDetailPage />;
      case 'cart':
        return <CartPage />;
      case 'confirmation':
        return <ConfirmationPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <main className="flex-1">
        {renderPage()}
      </main>
      <Footer />
      <TestHUD />
    </div>
  );
};

function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}

export default App;
