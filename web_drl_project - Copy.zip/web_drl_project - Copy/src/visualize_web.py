"""
Visualize trained DRL agent behavior in visible browser
Useful for demos and understanding agent behavior
"""
import argparse
import os
import sys
import time

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from envs.web.web_shop_env import WebShopEnv
from stable_baselines3 import PPO, A2C


def visualize(
    model_path: str,
    algo: str = "ppo",
    persona: str = "shopper",
    n_episodes: int = 1,
    seed: int = 1,
    delay: float = 1.0
):
    """
    Visualize agent behavior in visible browser
    
    Args:
        model_path: Path to trained model
        algo: Algorithm used (ppo or a2c)
        persona: Reward mode/persona
        n_episodes: Number of episodes to run
        seed: Random seed
        delay: Delay between actions in seconds
    """
    # Load model
    if algo.lower() == "ppo":
        model = PPO.load(model_path)
    elif algo.lower() == "a2c":
        model = A2C.load(model_path)
    else:
        raise ValueError(f"Unknown algorithm: {algo}")
    
    print(f"\n{'='*60}")
    print(f"Visualizing {algo.upper()} agent")
    print(f"Model: {model_path}")
    print(f"Persona: {persona}")
    print(f"Episodes: {n_episodes}")
    print(f"{'='*60}\n")
    
    # Create environment with visible browser
    env = WebShopEnv(
        reward_mode=persona,
        headless=False,  # Visible browser
        max_steps=50,
        seed=seed
    )
    
    action_names = [
        "Navigate to home",
        "Click product 1",
        "Click product 2",
        "Click product 3",
        "Click product 4",
        "Click product 5",
        "Click product 6",
        "Click product 7",
        "Click product 8",
        "Add to cart",
        "Go to cart",
        "Apply coupon SAVE10",
        "Apply coupon SAVE20",
        "Apply coupon WELCOME15",
        "Apply coupon HOLIDAY25",
        "Proceed to checkout",
        "Confirm order",
        "No-op"
    ]
    
    for episode in range(n_episodes):
        print(f"\n{'='*60}")
        print(f"Episode {episode + 1}/{n_episodes}")
        print(f"{'='*60}\n")
        
        obs, info = env.reset()
        episode_reward = 0
        steps = 0
        done = False
        
        print("Starting episode... Press Ctrl+C to stop\n")
        time.sleep(2)  # Give user time to see initial state
        
        try:
            while not done:
                # Get action from model
                action, _states = model.predict(obs, deterministic=True)
                
                print(f"Step {steps + 1}: {action_names[action]}")
                
                # Take action
                obs, reward, terminated, truncated, info = env.step(action)
                
                episode_reward += reward
                steps += 1
                done = terminated or truncated
                
                print(f"  Reward: {reward:.2f}")
                print(f"  Page: {info.get('page', 'unknown')}")
                print(f"  Cart items: {info.get('cart_items', 0)}")
                print(f"  Total: ${info.get('total', 0):.2f}")
                print()
                
                # Delay for visualization
                time.sleep(delay)
                
                if done:
                    print(f"\n{'='*60}")
                    print(f"Episode finished!")
                    print(f"Total reward: {episode_reward:.2f}")
                    print(f"Steps: {steps}")
                    print(f"Order completed: {info.get('order_complete', False)}")
                    print(f"{'='*60}\n")
                    
                    if episode < n_episodes - 1:
                        print("Starting next episode in 3 seconds...")
                        time.sleep(3)
        
        except KeyboardInterrupt:
            print("\n\nVisualization interrupted by user.")
            break
    
    # Close environment
    print("\nClosing browser...")
    env.close()
    print("Done!")


def main():
    parser = argparse.ArgumentParser(description="Visualize trained DRL agent behavior")
    parser.add_argument('--model', type=str, required=True,
                        help='Path to trained model (without .zip extension)')
    parser.add_argument('--algo', type=str, default='ppo', choices=['ppo', 'a2c'],
                        help='Algorithm used (default: ppo)')
    parser.add_argument('--persona', type=str, default='shopper', choices=['shopper', 'validator'],
                        help='Reward mode/persona (default: shopper)')
    parser.add_argument('--episodes', type=int, default=1,
                        help='Number of episodes to visualize (default: 1)')
    parser.add_argument('--seed', type=int, default=1,
                        help='Random seed (default: 1)')
    parser.add_argument('--delay', type=float, default=1.0,
                        help='Delay between actions in seconds (default: 1.0)')
    
    args = parser.parse_args()
    
    visualize(
        model_path=args.model,
        algo=args.algo,
        persona=args.persona,
        n_episodes=args.episodes,
        seed=args.seed,
        delay=args.delay
    )


if __name__ == "__main__":
    main()
