import React, { useState } from 'react';
import { useStore } from '../StoreContext';
import { PRODUCTS } from '../data';

export const ProductDetailPage: React.FC = () => {
  const { state, addToCart, setPage } = useStore();
  const [quantity, setQuantity] = useState(1);

  const product = PRODUCTS.find(p => p.id === state.selectedProductId);

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8" data-testid="pdp-not-found">
        <p>Product not found</p>
        <button onClick={() => setPage('home')} className="text-indigo-600">
          Back to Home
        </button>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product.id, quantity);
  };

  return (
    <div className="container mx-auto px-4 py-8" data-testid="pdp-page">
      <button
        onClick={() => setPage('home')}
        className="text-indigo-600 hover:text-indigo-800 mb-6 flex items-center"
        data-testid="back-to-home"
      >
        ← Back to Products
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <img
            src={product.image}
            alt={product.name}
            className="w-full rounded-lg shadow-lg"
            data-testid="pdp-image"
          />
        </div>

        <div>
          <div className="text-sm text-gray-500 mb-2" data-testid="pdp-category">
            {product.category}
          </div>

          <h1 className="text-3xl font-bold mb-4" data-testid="pdp-name">
            {product.name}
          </h1>

          <div className="text-4xl font-bold text-indigo-600 mb-6" data-testid="pdp-price">
            ${product.price.toFixed(2)}
          </div>

          <p className="text-gray-700 mb-6" data-testid="pdp-description">
            {product.description}
          </p>

          <div className="mb-6" data-testid="pdp-stock">
            <span className="font-semibold">Availability: </span>
            <span className={product.stock > 0 ? 'text-green-600' : 'text-red-600'}>
              {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
            </span>
          </div>

          <div className="flex items-center space-x-4 mb-6">
            <label className="font-semibold">Quantity:</label>
            <div className="flex items-center border rounded">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-4 py-2 hover:bg-gray-100"
                data-testid="quantity-decrease"
              >
                -
              </button>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-20 text-center border-x py-2"
                data-testid="quantity-input"
              />
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="px-4 py-2 hover:bg-gray-100"
                data-testid="quantity-increase"
              >
                +
              </button>
            </div>
          </div>

          <button
            onClick={handleAddToCart}
            disabled={product.stock === 0}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition disabled:bg-gray-400"
            data-testid="add-to-cart-button"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};
