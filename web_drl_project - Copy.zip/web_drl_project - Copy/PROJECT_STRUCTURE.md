# Project Structure Summary

## Complete Directory Structure

```
web_drl_project/
│
├── web_app/                          # React + TypeScript E-Commerce App
│   ├── src/
│   │   ├── components/
│   │   │   ├── Header.tsx           # Navigation header with cart
│   │   │   ├── Footer.tsx           # Footer with links
│   │   │   └── TestHUD.tsx          # Debug overlay showing state
│   │   │
│   │   ├── pages/
│   │   │   ├── HomePage.tsx         # Product catalog grid
│   │   │   ├── ProductDetailPage.tsx # Individual product view
│   │   │   ├── CartPage.tsx         # Shopping cart + checkout modal
│   │   │   └── ConfirmationPage.tsx # Order confirmation
│   │   │
│   │   ├── App.tsx                  # Main app component
│   │   ├── main.tsx                 # Entry point
│   │   ├── StoreContext.tsx         # Global state management + API
│   │   ├── types.ts                 # TypeScript interfaces
│   │   ├── data.ts                  # Products, coupons, constants
│   │   └── index.css                # Tailwind styles
│   │
│   ├── public/
│   ├── dist/                        # Built static site (created by npm run build)
│   ├── index.html
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   └── postcss.config.js
│
├── envs/                            # Python Gymnasium Environments
│   ├── __init__.py
│   └── web/
│       ├── __init__.py
│       └── web_shop_env.py         # Playwright-controlled environment
│
├── src/                             # Training, Evaluation, Visualization
│   ├── train_web.py                # Train PPO/A2C agents
│   ├── eval_web.py                 # Evaluate trained agents
│   └── visualize_web.py            # Watch agents in visible browser
│
├── configs/                         # YAML Configuration Files
│   ├── ppo.yaml                    # PPO hyperparameters
│   ├── a2c.yaml                    # A2C hyperparameters
│   └── reward_modes.yaml           # Personas and reward definitions
│
├── logs/                            # Training Logs and Results
│   ├── ppo_web_shopper_seed1/      # (created during training)
│   ├── a2c_web_validator_seed1/    # (created during training)
│   └── eval_*.csv                  # (created during evaluation)
│
├── models/                          # Saved Trained Agents
│   ├── ppo_web_shopper_seed1.zip   # (created during training)
│   └── a2c_web_validator_seed1.zip # (created during training)
│
├── README.md                        # Full documentation
├── QUICKSTART.md                    # Quick start guide
├── requirements.txt                 # Python dependencies
├── test_setup.py                    # Setup verification script
└── .gitignore                       # Git ignore rules
```

## Key Components

### 1. Web Application (React + TypeScript)

**Purpose**: Deterministic e-commerce site for DRL testing

**Key Features**:
- ✅ Frontend-only (no backend)
- ✅ Deterministic behavior
- ✅ Global state API (`window.mockStoreAPI`)
- ✅ Test HUD for debugging
- ✅ Full `data-testid` instrumentation
- ✅ Bug simulation via URL params
- ✅ Telemetry logging

**Pages**:
1. **Home**: Product catalog with 8 items
2. **Product Detail**: Individual product view with quantity selector
3. **Cart**: Shopping cart with coupon input
4. **Checkout Modal**: Form-based checkout
5. **Confirmation**: Order success page

**Global API**:
```javascript
window.mockStoreAPI = {
  getState: () => ({ cartItems, subtotal, tax, shipping, total, coupon, page, orderNumber }),
  reset: () => {},
  applyCoupon: (code: string) => boolean
}
```

### 2. Python DRL Environment (Gymnasium)

**Purpose**: Playwright-controlled browser automation for RL training

**Key Features**:
- ✅ Gymnasium-compatible interface
- ✅ 18 discrete actions (navigation, cart ops, coupons, checkout)
- ✅ 8-dimensional observation space
- ✅ Two reward modes (personas): shopper & validator
- ✅ Headless or visible browser mode
- ✅ Screenshot capture support

**Action Space** (18 actions):
- Navigate home, click products 1-8
- Add to cart, go to cart
- Apply coupons (4 different codes)
- Checkout, confirm order, no-op

**Observation Space** (8 features):
- Page type, cart count, subtotal, tax, shipping, total, has_coupon, order_complete

### 3. Training Scripts (Stable-Baselines3)

**train_web.py**: Train PPO or A2C agents
- Supports configurable seeds, personas, hyperparameters
- Logs to TensorBoard
- Saves checkpoints and final models

**eval_web.py**: Evaluate trained agents
- Runs N episodes with detailed metrics
- Saves CSV results
- Optional screenshot capture

**visualize_web.py**: Watch agents in action
- Visible browser mode
- Step-by-step action display
- Configurable delay between actions

### 4. Configuration Files (YAML)

**ppo.yaml**: PPO hyperparameters
- Learning rate, batch size, n_steps, etc.

**a2c.yaml**: A2C hyperparameters
- Learning rate, n_steps, entropy coefficient, etc.

**reward_modes.yaml**: Persona definitions
- Shopper: Quick checkout optimization
- Validator: Bug detection and testing

## Workflow

```mermaid
graph LR
    A[Build Web App] --> B[Train Agent]
    B --> C[Evaluate Agent]
    C --> D[Visualize Behavior]
    D --> E[Analyze Results]
    E --> F[Iterate & Improve]
    F --> B
```

### Step-by-Step Workflow

1. **Setup** (one-time):
   ```bash
   cd web_app && npm install && npm run build
   pip install -r requirements.txt
   playwright install chromium
   ```

2. **Train**:
   ```bash
   python src/train_web.py --algo=ppo --persona=shopper --seed=1
   ```

3. **Evaluate**:
   ```bash
   python src/eval_web.py --model=models/ppo_web_shopper_seed1 --algo=ppo --persona=shopper --episodes=10
   ```

4. **Visualize**:
   ```bash
   python src/visualize_web.py --model=models/ppo_web_shopper_seed1 --algo=ppo --persona=shopper
   ```

5. **Analyze**:
   - View TensorBoard: `tensorboard --logdir=logs`
   - Check CSVs in `logs/`
   - Compare personas and algorithms

## Comparison with Game Project

| Aspect | Game Project | Web Project |
|--------|--------------|-------------|
| **Environment** | Pygame 2D game | React web app |
| **Control** | Keyboard/game loop | Playwright browser |
| **Observation** | Game state array | Web state API |
| **Actions** | Game controls | Browser interactions |
| **Personas** | speedrunner, survivor | shopper, validator |
| **Algorithms** | PPO, A2C | PPO, A2C |
| **Structure** | `/game`, `/envs`, `/src` | `/web_app`, `/envs`, `/src` |
| **Logging** | CSV + TensorBoard | CSV + TensorBoard |
| **Reproducibility** | Seeds + configs | Seeds + configs |

## Design Principles

1. **Modularity**: Clear separation of concerns (web app, env, training)
2. **Reproducibility**: Fixed seeds, pinned deps, config files
3. **Instrumentation**: Full test coverage with data-testid
4. **Observability**: Test HUD, telemetry, TensorBoard logs
5. **Extensibility**: Easy to add products, actions, personas
6. **Consistency**: Mirrors game project architecture

## Technologies Used

### Frontend
- React 18
- TypeScript
- Vite
- Tailwind CSS

### Backend/DRL
- Python 3.9+
- Gymnasium
- Stable-Baselines3 (PPO, A2C)
- Playwright
- PyTorch
- NumPy, Pandas
- TensorBoard

## Next Steps

1. ✅ Build web app: `cd web_app && npm run build`
2. ✅ Install Python deps: `pip install -r requirements.txt`
3. ✅ Test setup: `python test_setup.py`
4. ✅ Train first agent: `python src/train_web.py --algo=ppo --persona=shopper --seed=1`
5. ✅ Evaluate: `python src/eval_web.py --model=models/ppo_web_shopper_seed1`
6. ✅ Visualize: `python src/visualize_web.py --model=models/ppo_web_shopper_seed1`
7. 📊 Compare algorithms and personas
8. 🔧 Customize reward functions
9. 🧪 Add bug simulations
10. 📈 Analyze learning curves

---

**Built to mirror the Pygame DRL project structure while targeting web application testing.**
