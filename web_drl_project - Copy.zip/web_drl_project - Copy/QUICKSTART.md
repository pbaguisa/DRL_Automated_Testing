# Quick Start Guide - Web DRL E-Commerce Testing

## 🚀 Fastest Path to Running Your First Agent

### Step 1: Build the Web App (5 minutes)

```bash
cd web_app
npm install
npm run build
cd ..
```

### Step 2: Set Up Python Environment (5 minutes)

```bash
# Create and activate virtual environment
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Install Playwright browser
playwright install chromium
```

### Step 3: Train Your First Agent (5-10 minutes)

```bash
# Train a PPO agent with shopper persona
python src/train_web.py --algo=ppo --persona=shopper --seed=1 --timesteps=10000
```

### Step 4: Watch Your Agent in Action

```bash
# Visualize the trained agent (visible browser)
python src/visualize_web.py --model=models/ppo_web_shopper_seed1 --algo=ppo --persona=shopper --delay=1.5
```

### Step 5: Evaluate Performance

```bash
# Run 10 test episodes
python src/eval_web.py --model=models/ppo_web_shopper_seed1 --algo=ppo --persona=shopper --episodes=10
```

## 📊 View Training Progress

```bash
tensorboard --logdir=logs
# Open browser to http://localhost:6006
```

## 🎯 Common Training Scenarios

### Scenario 1: Fast Shopper Agent
Train an agent to complete purchases quickly:
```bash
python src/train_web.py --algo=ppo --persona=shopper --seed=1 --timesteps=50000
```

### Scenario 2: Bug Hunter Agent
Train an agent to find bugs and edge cases:
```bash
python src/train_web.py --algo=ppo --persona=validator --seed=1 --timesteps=50000
```

### Scenario 3: Compare Algorithms
Train both PPO and A2C:
```bash
python src/train_web.py --algo=ppo --persona=shopper --seed=1 --timesteps=30000
python src/train_web.py --algo=a2c --persona=shopper --seed=1 --timesteps=30000
```

## 🔍 Understanding Results

After evaluation, check `logs/eval_*.csv` for:
- `total_reward`: Higher is better
- `steps`: Lower means more efficient
- `order_completed`: Should be True for shopper
- `cart_operations`: Number of cart interactions
- `coupon_attempts`: Number of coupon tries

## ⚡ Quick Tips

1. **Reduce training time**: Use `--timesteps=10000` for quick tests
2. **Debug agent behavior**: Use `visualize_web.py` with `--delay=2.0` to see actions clearly
3. **Compare runs**: Use same `--seed` for reproducible comparisons
4. **Monitor training**: Run TensorBoard in a separate terminal

## 🐛 Quick Troubleshooting

**Problem**: "Cannot find module 'react'"
- **Solution**: Run `npm install` in `web_app/` directory

**Problem**: "Playwright not installed"
- **Solution**: Run `playwright install chromium`

**Problem**: "Cannot find dist/index.html"
- **Solution**: Run `npm run build` in `web_app/` directory

**Problem**: Agent isn't learning
- **Solution**: Increase `--timesteps` to 50000 or 100000

## 🎓 Next Steps

1. ✅ Complete Quick Start above
2. 📖 Read full README.md for detailed documentation
3. 🔧 Customize reward functions in `envs/web/web_shop_env.py`
4. 📊 Analyze results and compare algorithms
5. 🎯 Add custom test scenarios

## 💡 Example Training Commands

```bash
# Quick test (10k steps, ~5 minutes)
python src/train_web.py --algo=ppo --persona=shopper --seed=1 --timesteps=10000

# Standard training (50k steps, ~20 minutes)
python src/train_web.py --algo=ppo --persona=shopper --seed=1 --timesteps=50000

# Full training (100k steps, ~40 minutes)
python src/train_web.py --algo=ppo --persona=shopper --seed=1 --timesteps=100000
```

---

🎉 **You're ready to train DRL agents for web testing!**
