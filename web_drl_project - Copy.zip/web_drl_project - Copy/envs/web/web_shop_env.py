"""
Web Shop Environment for DRL Testing
Uses Playwright to interact with the e-commerce web application
"""
import gymnasium as gym
from gymnasium import spaces
import numpy as np
from playwright.sync_api import sync_playwright, Page, Browser
import time
import os
from typing import Optional, Dict, Any, Tuple

class WebShopEnv(gym.Env):
    """
    Gymnasium environment for testing web e-commerce application
    
    Action Space:
        0: Navigate to home
        1: Click product 1
        2: Click product 2
        3: Click product 3
        4: Click product 4
        5: Click product 5
        6: Click product 6
        7: Click product 7
        8: Click product 8
        9: Add to cart (on PDP)
        10: Go to cart
        11: Apply coupon SAVE10
        12: Apply coupon SAVE20
        13: Apply coupon WELCOME15
        14: Apply coupon HOLIDAY25
        15: Proceed to checkout
        16: Confirm order
        17: No-op
    
    Observation Space:
        - page (0=home, 1=pdp, 2=cart, 3=checkout, 4=confirmation)
        - cart_items_count
        - subtotal (normalized 0-3000)
        - tax (normalized 0-400)
        - shipping (normalized 0-20)
        - total (normalized 0-3500)
        - has_coupon (binary)
        - order_complete (binary)
    
    Reward Modes (Personas):
        - shopper: Rewards quick, valid checkout
        - validator: Rewards detecting price mismatches or bugs
    """
    
    metadata = {"render_modes": ["human", "rgb_array"]}
    
    def __init__(
        self,
        reward_mode: str = "shopper",
        headless: bool = True,
        max_steps: int = 50,
        app_url: Optional[str] = None,
        seed: Optional[int] = None,
    ):
        super().__init__()
        
        self.reward_mode = reward_mode
        self.headless = headless
        self.max_steps = max_steps
        self.seed_value = seed
        
        # Determine app URL - use static build
        if app_url is None:
            # Default to local file path
            script_dir = os.path.dirname(os.path.abspath(__file__))
            dist_path = os.path.join(script_dir, "..", "..", "web_app", "dist", "index.html")
            self.app_url = f"file:///{os.path.abspath(dist_path).replace(os.sep, '/')}"
        else:
            self.app_url = app_url
        
        # Action space: 18 discrete actions
        self.action_space = spaces.Discrete(18)
        
        # Observation space: 8 features
        self.observation_space = spaces.Box(
            low=np.array([0, 0, 0, 0, 0, 0, 0, 0], dtype=np.float32),
            high=np.array([4, 100, 3000, 400, 20, 3500, 1, 1], dtype=np.float32),
            dtype=np.float32
        )
        
        # Playwright instances
        self.playwright = None
        self.browser: Optional[Browser] = None
        self.page: Optional[Page] = None
        
        # Episode state
        self.steps = 0
        self.episode_reward = 0
        self.last_state = None
        
        # Seed RNG
        if seed is not None:
            np.random.seed(seed)
    
    def _launch_browser(self):
        """Launch Playwright browser"""
        if self.playwright is None:
            self.playwright = sync_playwright().start()
            self.browser = self.playwright.chromium.launch(headless=self.headless)
            self.page = self.browser.new_page()
            self.page.goto(self.app_url)
            time.sleep(2)  # Wait for app to load
    
    def _close_browser(self):
        """Close Playwright browser"""
        if self.page:
            self.page.close()
            self.page = None
        if self.browser:
            self.browser.close()
            self.browser = None
        if self.playwright:
            self.playwright.stop()
            self.playwright = None
    
    def _get_state(self) -> Dict[str, Any]:
        """Get current state from window.mockStoreAPI"""
        try:
            state = self.page.evaluate("() => window.mockStoreAPI.getState()")
            return state
        except Exception as e:
            print(f"Error getting state: {e}")
            return {
                'page': 'home',
                'cartItems': [],
                'subtotal': 0,
                'tax': 0,
                'shipping': 0,
                'total': 0,
                'coupon': None,
                'orderNumber': None,
            }
    
    def _state_to_observation(self, state: Dict[str, Any]) -> np.ndarray:
        """Convert state dict to observation array"""
        page_map = {'home': 0, 'pdp': 1, 'cart': 2, 'checkout': 3, 'confirmation': 4}
        
        obs = np.array([
            page_map.get(state.get('page', 'home'), 0),
            len(state.get('cartItems', [])),
            min(state.get('subtotal', 0), 3000),
            min(state.get('tax', 0), 400),
            min(state.get('shipping', 0), 20),
            min(state.get('total', 0), 3500),
            1 if state.get('coupon') else 0,
            1 if state.get('orderNumber') else 0,
        ], dtype=np.float32)
        
        return obs
    
    def _execute_action(self, action: int):
        """Execute action on the web page"""
        try:
            if action == 0:  # Navigate to home
                self.page.click('[data-testid="logo"]')
            elif 1 <= action <= 8:  # Click product
                product_id = action
                self.page.click(f'[data-testid="product-card-{product_id}"]')
            elif action == 9:  # Add to cart (on PDP)
                self.page.click('[data-testid="add-to-cart-button"]')
            elif action == 10:  # Go to cart
                self.page.click('[data-testid="cart-button"]')
            elif action == 11:  # Apply coupon SAVE10
                self.page.fill('[data-testid="coupon-input"]', 'SAVE10')
                self.page.click('[data-testid="apply-coupon-button"]')
            elif action == 12:  # Apply coupon SAVE20
                self.page.fill('[data-testid="coupon-input"]', 'SAVE20')
                self.page.click('[data-testid="apply-coupon-button"]')
            elif action == 13:  # Apply coupon WELCOME15
                self.page.fill('[data-testid="coupon-input"]', 'WELCOME15')
                self.page.click('[data-testid="apply-coupon-button"]')
            elif action == 14:  # Apply coupon HOLIDAY25
                self.page.fill('[data-testid="coupon-input"]', 'HOLIDAY25')
                self.page.click('[data-testid="apply-coupon-button"]')
            elif action == 15:  # Proceed to checkout
                self.page.click('[data-testid="checkout-button"]')
            elif action == 16:  # Confirm order
                # Fill in checkout form
                self.page.fill('[data-testid="checkout-email"]', 'test@example.com')
                self.page.fill('[data-testid="checkout-name"]', 'Test User')
                self.page.fill('[data-testid="checkout-address"]', '123 Test St')
                self.page.fill('[data-testid="checkout-city"]', 'TestCity')
                self.page.fill('[data-testid="checkout-postal"]', 'A1B2C3')
                self.page.fill('[data-testid="checkout-card"]', '4111111111111111')
                self.page.click('[data-testid="confirm-order-button"]')
            # action == 17 is no-op
            
            time.sleep(0.5)  # Wait for action to complete
        except Exception as e:
            print(f"Error executing action {action}: {e}")
    
    def _calculate_reward(self, prev_state: Dict, curr_state: Dict, action: int) -> float:
        """Calculate reward based on persona/reward mode"""
        reward = 0.0
        
        if self.reward_mode == "shopper":
            # Reward for progressing through checkout flow
            prev_page = prev_state.get('page', 'home')
            curr_page = curr_state.get('page', 'home')
            
            # Reward for adding items to cart
            if len(curr_state.get('cartItems', [])) > len(prev_state.get('cartItems', [])):
                reward += 5.0
            
            # Reward for moving forward in checkout
            page_progression = {'home': 0, 'pdp': 1, 'cart': 2, 'checkout': 3, 'confirmation': 4}
            if page_progression.get(curr_page, 0) > page_progression.get(prev_page, 0):
                reward += 10.0
            
            # Big reward for completing order
            if curr_state.get('orderNumber') and not prev_state.get('orderNumber'):
                reward += 100.0
            
            # Apply valid coupon
            if curr_state.get('coupon') and not prev_state.get('coupon'):
                reward += 15.0
            
            # Small penalty for each step to encourage efficiency
            reward -= 0.5
        
        elif self.reward_mode == "validator":
            # Reward for detecting anomalies or testing edge cases
            
            # Reward for trying coupons (testing validation)
            if action in [11, 12, 13, 14]:
                reward += 2.0
            
            # Reward for testing cart operations
            if len(curr_state.get('cartItems', [])) != len(prev_state.get('cartItems', [])):
                reward += 3.0
            
            # Reward for price validation checks
            subtotal = curr_state.get('subtotal', 0)
            cart_items = curr_state.get('cartItems', [])
            if cart_items:
                # Check if subtotal matches cart items
                expected_subtotal = sum(item['price'] * item['quantity'] for item in cart_items)
                if abs(subtotal - expected_subtotal) > 0.01:
                    # Detected mismatch!
                    reward += 50.0
            
            # Reward for completing validation flow
            if curr_state.get('orderNumber'):
                reward += 30.0
            
            # Small penalty for each step
            reward -= 0.3
        
        return reward
    
    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Reset environment"""
        super().reset(seed=seed)
        
        # Close and relaunch browser
        self._close_browser()
        self._launch_browser()
        
        # Reset state
        self.steps = 0
        self.episode_reward = 0
        
        # Get initial state
        state = self._get_state()
        self.last_state = state
        obs = self._state_to_observation(state)
        
        return obs, {}
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """Take action and return result"""
        self.steps += 1
        
        # Get state before action
        prev_state = self._get_state()
        
        # Execute action
        self._execute_action(action)
        
        # Get state after action
        curr_state = self._get_state()
        self.last_state = curr_state
        
        # Calculate reward
        reward = self._calculate_reward(prev_state, curr_state, action)
        self.episode_reward += reward
        
        # Check termination
        terminated = curr_state.get('orderNumber') is not None
        truncated = self.steps >= self.max_steps
        
        # Get observation
        obs = self._state_to_observation(curr_state)
        
        # Info dict
        info = {
            'steps': self.steps,
            'episode_reward': self.episode_reward,
            'page': curr_state.get('page'),
            'cart_items': len(curr_state.get('cartItems', [])),
            'total': curr_state.get('total', 0),
            'order_complete': terminated,
        }
        
        return obs, reward, terminated, truncated, info
    
    def render(self):
        """Render environment (browser is already visible if headless=False)"""
        pass
    
    def close(self):
        """Close environment"""
        self._close_browser()
