import React, { useState } from 'react';
import { useStore } from '../StoreContext';

export const TestHUD: React.FC = () => {
  const { state } = useStore();
  const [isMinimized, setIsMinimized] = useState(false);

  if (isMinimized) {
    return (
      <div
        className="fixed bottom-4 right-4 bg-black bg-opacity-80 text-white p-2 rounded cursor-pointer z-50"
        onClick={() => setIsMinimized(false)}
        data-testid="test-hud-minimized"
      >
        <span className="text-xs">📊 HUD</span>
      </div>
    );
  }

  return (
    <div
      className="fixed bottom-4 right-4 bg-black bg-opacity-90 text-white p-4 rounded-lg shadow-lg text-xs font-mono max-w-sm z-50"
      data-testid="test-hud"
    >
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-bold text-sm">Test HUD</h3>
        <button
          onClick={() => setIsMinimized(true)}
          className="text-gray-400 hover:text-white"
          data-testid="minimize-hud"
        >
          _
        </button>
      </div>

      <div className="space-y-1">
        <div data-testid="hud-page">
          <span className="text-gray-400">Page:</span>{' '}
          <span className="text-green-400">{state.page}</span>
        </div>

        <div data-testid="hud-cart-items">
          <span className="text-gray-400">Cart Items:</span>{' '}
          <span className="text-yellow-400">{state.cartItems.length}</span>
        </div>

        <div data-testid="hud-subtotal">
          <span className="text-gray-400">Subtotal:</span>{' '}
          <span className="text-yellow-400">${state.subtotal.toFixed(2)}</span>
        </div>

        <div data-testid="hud-tax">
          <span className="text-gray-400">Tax:</span>{' '}
          <span className="text-yellow-400">${state.tax.toFixed(2)}</span>
        </div>

        <div data-testid="hud-shipping">
          <span className="text-gray-400">Shipping:</span>{' '}
          <span className="text-yellow-400">${state.shipping.toFixed(2)}</span>
        </div>

        <div data-testid="hud-total">
          <span className="text-gray-400">Total:</span>{' '}
          <span className="text-green-400 font-bold">${state.total.toFixed(2)}</span>
        </div>

        {state.coupon && (
          <div data-testid="hud-coupon">
            <span className="text-gray-400">Coupon:</span>{' '}
            <span className="text-blue-400">
              {state.coupon.code} (-${state.coupon.discountValue})
            </span>
          </div>
        )}

        {state.orderNumber && (
          <div data-testid="hud-order">
            <span className="text-gray-400">Order:</span>{' '}
            <span className="text-purple-400">{state.orderNumber}</span>
          </div>
        )}
      </div>

      <div className="mt-3 pt-2 border-t border-gray-700">
        <button
          onClick={() => window.downloadTelemetryCSV()}
          className="text-xs text-blue-400 hover:text-blue-300"
          data-testid="download-telemetry"
        >
          📥 Download Telemetry
        </button>
      </div>
    </div>
  );
};
