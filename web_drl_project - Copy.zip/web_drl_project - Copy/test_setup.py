"""
Demo script to verify web DRL setup
Tests environment creation and basic functionality
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from envs.web.web_shop_env import WebShopEnv
import numpy as np


def test_environment():
    """Test basic environment functionality"""
    print("\n" + "="*60)
    print("Web DRL Environment Test")
    print("="*60 + "\n")
    
    # Create environment
    print("Creating environment...")
    env = WebShopEnv(
        reward_mode="shopper",
        headless=True,
        max_steps=20,
        seed=1
    )
    print("✓ Environment created\n")
    
    # Test reset
    print("Resetting environment...")
    obs, info = env.reset()
    print(f"✓ Environment reset")
    print(f"  Observation shape: {obs.shape}")
    print(f"  Observation: {obs}\n")
    
    # Test a few random actions
    print("Testing random actions...")
    for i in range(5):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        
        print(f"Step {i+1}:")
        print(f"  Action: {action}")
        print(f"  Reward: {reward:.2f}")
        print(f"  Page: {info.get('page', 'unknown')}")
        print(f"  Cart items: {info.get('cart_items', 0)}")
        print(f"  Terminated: {terminated}, Truncated: {truncated}\n")
        
        if terminated or truncated:
            break
    
    # Close environment
    print("Closing environment...")
    env.close()
    print("✓ Environment closed\n")
    
    print("="*60)
    print("Environment test completed successfully!")
    print("="*60 + "\n")
    
    print("Next steps:")
    print("1. Build web app: cd web_app && npm run build")
    print("2. Train an agent: python src/train_web.py --algo=ppo --persona=shopper --seed=1")
    print("3. Visualize agent: python src/visualize_web.py --model=models/ppo_web_shopper_seed1")
    print()


if __name__ == "__main__":
    try:
        test_environment()
    except Exception as e:
        print(f"\n❌ Error: {e}\n")
        print("Troubleshooting:")
        print("- Ensure web app is built: cd web_app && npm run build")
        print("- Check Playwright is installed: playwright install chromium")
        print("- Verify all dependencies: pip install -r requirements.txt")
        sys.exit(1)
