export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  category: string;
  image: string;
  stock: number;
}

export interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}

export interface Coupon {
  code: string;
  discountValue: number;
}

export interface StoreState {
  cartItems: CartItem[];
  subtotal: number;
  tax: number;
  shipping: number;
  total: number;
  coupon: Coupon | null;
  page: 'home' | 'pdp' | 'cart' | 'checkout' | 'confirmation';
  selectedProductId: number | null;
  orderNumber: string | null;
}

export interface TelemetryEvent {
  timestamp: number;
  event: string;
  data: Record<string, any>;
}

export interface MockStoreAPI {
  getState: () => StoreState;
  reset: () => void;
  applyCoupon: (code: string) => boolean;
}

declare global {
  interface Window {
    mockStoreAPI: MockStoreAPI;
    __telemetry: TelemetryEvent[];
    downloadTelemetryCSV: () => void;
  }
}
