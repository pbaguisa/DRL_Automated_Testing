"""
Train DRL agent on web e-commerce environment
Supports PPO and A2C algorithms with configurable personas and seeds
"""
import argparse
import os
import sys
from datetime import datetime
import yaml

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from envs.web.web_shop_env import WebShopEnv
from stable_baselines3 import PPO, A2C
from stable_baselines3.common.callbacks import CheckpointCallback, EvalCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv
import numpy as np


def make_env(reward_mode: str, seed: int):
    """Factory function to create environment"""
    def _init():
        env = WebShopEnv(
            reward_mode=reward_mode,
            headless=True,
            max_steps=50,
            seed=seed
        )
        env = Monitor(env)
        return env
    return _init


def train(
    algo: str = "ppo",
    persona: str = "shopper",
    seed: int = 1,
    total_timesteps: int = 50000,
    config_path: str = None
):
    """
    Train DRL agent
    
    Args:
        algo: Algorithm to use (ppo or a2c)
        persona: Reward mode/persona (shopper or validator)
        seed: Random seed for reproducibility
        total_timesteps: Total training timesteps
        config_path: Path to config YAML file
    """
    # Set seeds
    np.random.seed(seed)
    
    # Load config if provided
    config = {}
    if config_path and os.path.exists(config_path):
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
    
    # Create environment
    env = DummyVecEnv([make_env(persona, seed)])
    
    # Create logs directory
    log_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "logs",
        f"{algo}_web_{persona}_seed{seed}"
    )
    os.makedirs(log_dir, exist_ok=True)
    
    # Create models directory
    model_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "models"
    )
    os.makedirs(model_dir, exist_ok=True)
    
    # Model save path
    model_name = f"{algo}_web_{persona}_seed{seed}"
    model_path = os.path.join(model_dir, model_name)
    
    # Checkpoint callback
    checkpoint_callback = CheckpointCallback(
        save_freq=5000,
        save_path=log_dir,
        name_prefix=f"{algo}_checkpoint"
    )
    
    # Create agent
    if algo.lower() == "ppo":
        hyperparams = config.get('ppo', {}) if config else {}
        model = PPO(
            "MlpPolicy",
            env,
            learning_rate=hyperparams.get('learning_rate', 3e-4),
            n_steps=hyperparams.get('n_steps', 2048),
            batch_size=hyperparams.get('batch_size', 64),
            n_epochs=hyperparams.get('n_epochs', 10),
            gamma=hyperparams.get('gamma', 0.99),
            gae_lambda=hyperparams.get('gae_lambda', 0.95),
            clip_range=hyperparams.get('clip_range', 0.2),
            verbose=1,
            tensorboard_log=log_dir,
            seed=seed
        )
    elif algo.lower() == "a2c":
        hyperparams = config.get('a2c', {}) if config else {}
        model = A2C(
            "MlpPolicy",
            env,
            learning_rate=hyperparams.get('learning_rate', 7e-4),
            n_steps=hyperparams.get('n_steps', 5),
            gamma=hyperparams.get('gamma', 0.99),
            gae_lambda=hyperparams.get('gae_lambda', 1.0),
            ent_coef=hyperparams.get('ent_coef', 0.01),
            vf_coef=hyperparams.get('vf_coef', 0.5),
            verbose=1,
            tensorboard_log=log_dir,
            seed=seed
        )
    else:
        raise ValueError(f"Unknown algorithm: {algo}")
    
    # Train
    print(f"\n{'='*60}")
    print(f"Training {algo.upper()} agent")
    print(f"Persona: {persona}")
    print(f"Seed: {seed}")
    print(f"Total timesteps: {total_timesteps}")
    print(f"Log directory: {log_dir}")
    print(f"Model save path: {model_path}")
    print(f"{'='*60}\n")
    
    start_time = datetime.now()
    model.learn(
        total_timesteps=total_timesteps,
        callback=checkpoint_callback,
        progress_bar=True
    )
    end_time = datetime.now()
    
    # Save final model
    model.save(model_path)
    print(f"\n{'='*60}")
    print(f"Training complete!")
    print(f"Duration: {end_time - start_time}")
    print(f"Model saved to: {model_path}.zip")
    print(f"{'='*60}\n")
    
    # Save training metadata
    metadata = {
        'algo': algo,
        'persona': persona,
        'seed': seed,
        'total_timesteps': total_timesteps,
        'training_duration': str(end_time - start_time),
        'model_path': f"{model_path}.zip",
        'log_dir': log_dir,
    }
    
    metadata_path = os.path.join(log_dir, 'training_metadata.yaml')
    with open(metadata_path, 'w') as f:
        yaml.dump(metadata, f)
    
    # Close environment
    env.close()
    
    return model_path


def main():
    parser = argparse.ArgumentParser(description="Train DRL agent on web shop environment")
    parser.add_argument('--algo', type=str, default='ppo', choices=['ppo', 'a2c'],
                        help='Algorithm to use (default: ppo)')
    parser.add_argument('--persona', type=str, default='shopper', choices=['shopper', 'validator'],
                        help='Reward mode/persona (default: shopper)')
    parser.add_argument('--seed', type=int, default=1,
                        help='Random seed (default: 1)')
    parser.add_argument('--timesteps', type=int, default=50000,
                        help='Total training timesteps (default: 50000)')
    parser.add_argument('--config', type=str, default=None,
                        help='Path to config YAML file')
    
    args = parser.parse_args()
    
    # Load config from default location if not provided
    if args.config is None:
        config_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "configs"
        )
        args.config = os.path.join(config_dir, f"{args.algo}.yaml")
    
    train(
        algo=args.algo,
        persona=args.persona,
        seed=args.seed,
        total_timesteps=args.timesteps,
        config_path=args.config
    )


if __name__ == "__main__":
    main()
