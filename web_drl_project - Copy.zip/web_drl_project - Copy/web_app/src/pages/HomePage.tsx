import React from 'react';
import { useStore } from '../StoreContext';
import { PRODUCTS } from '../data';

export const HomePage: React.FC = () => {
  const { setPage, setSelectedProduct, addToCart } = useStore();

  const handleProductClick = (productId: number) => {
    setSelectedProduct(productId);
    setPage('pdp');
  };

  const handleQuickAdd = (e: React.MouseEvent, productId: number) => {
    e.stopPropagation();
    addToCart(productId, 1);
  };

  return (
    <div className="container mx-auto px-4 py-8" data-testid="home-page">
      <h1 className="text-3xl font-bold mb-8">Featured Products</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {PRODUCTS.map(product => (
          <div
            key={product.id}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition cursor-pointer"
            onClick={() => handleProductClick(product.id)}
            data-testid={`product-card-${product.id}`}
          >
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
              data-testid={`product-image-${product.id}`}
            />
            
            <div className="p-4">
              <div className="text-sm text-gray-500 mb-1" data-testid={`product-category-${product.id}`}>
                {product.category}
              </div>
              
              <h3 className="text-lg font-semibold mb-2" data-testid={`product-name-${product.id}`}>
                {product.name}
              </h3>
              
              <p className="text-gray-600 text-sm mb-4 line-clamp-2" data-testid={`product-description-${product.id}`}>
                {product.description}
              </p>
              
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-indigo-600" data-testid={`product-price-${product.id}`}>
                  ${product.price.toFixed(2)}
                </span>
                
                <button
                  onClick={(e) => handleQuickAdd(e, product.id)}
                  className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition"
                  data-testid={`quick-add-${product.id}`}
                >
                  Add to Cart
                </button>
              </div>
              
              <div className="mt-2 text-sm text-gray-500" data-testid={`product-stock-${product.id}`}>
                {product.stock} in stock
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
