import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CartItem, Coupon, StoreState, TelemetryEvent } from './types';
import { PRODUCTS, COUPONS, TAX_RATE, SHIPPING_COST, SHIPPING_THRESHOLD } from './data';

interface StoreContextType {
  state: StoreState;
  addToCart: (productId: number, quantity?: number) => void;
  removeFromCart: (productId: number) => void;
  updateCartQuantity: (productId: number, quantity: number) => void;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  setPage: (page: StoreState['page']) => void;
  setSelectedProduct: (productId: number | null) => void;
  checkout: () => void;
  reset: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within StoreProvider');
  }
  return context;
};

// Parse URL parameters for bug simulation
const urlParams = new URLSearchParams(window.location.search);
const BUG_SUBTOTAL_MISMATCH = urlParams.get('bugSubtotalMismatch') === '1';
const BUG_DOUBLE_COUPON = urlParams.get('bugDoubleCoupon') === '1';
const BUG_CHECKOUT_DISABLED = urlParams.get('bugCheckoutDisabled') === '1';

// Telemetry logging
const telemetry: TelemetryEvent[] = [];

const logEvent = (event: string, data: Record<string, any> = {}) => {
  telemetry.push({
    timestamp: Date.now(),
    event,
    data,
  });
};

// CSV download function
window.downloadTelemetryCSV = () => {
  const headers = ['timestamp', 'event', 'data'];
  const rows = telemetry.map(t => [
    t.timestamp,
    t.event,
    JSON.stringify(t.data),
  ]);
  const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `telemetry_${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
};

window.__telemetry = telemetry;

const initialState: StoreState = {
  cartItems: [],
  subtotal: 0,
  tax: 0,
  shipping: 0,
  total: 0,
  coupon: null,
  page: 'home',
  selectedProductId: null,
  orderNumber: null,
};

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<StoreState>(initialState);

  // Calculate totals whenever cart or coupon changes
  useEffect(() => {
    const subtotal = state.cartItems.reduce((sum, item) => {
      // Bug simulation: subtotal mismatch
      if (BUG_SUBTOTAL_MISMATCH && item.id === 1) {
        return sum + item.price * item.quantity * 0.9; // Wrong calculation
      }
      return sum + item.price * item.quantity;
    }, 0);

    let discount = 0;
    if (state.coupon) {
      discount = state.coupon.discountValue;
      // Bug simulation: double coupon application
      if (BUG_DOUBLE_COUPON) {
        discount = discount * 2;
      }
    }

    const discountedSubtotal = Math.max(0, subtotal - discount);
    const tax = discountedSubtotal * TAX_RATE;
    const shipping = discountedSubtotal >= SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
    const total = discountedSubtotal + tax + shipping;

    setState(prev => ({
      ...prev,
      subtotal,
      tax,
      shipping,
      total,
    }));
  }, [state.cartItems, state.coupon]);

  const addToCart = (productId: number, quantity = 1) => {
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product) return;

    logEvent('add_to_cart', { productId, quantity, price: product.price });

    setState(prev => {
      const existingItem = prev.cartItems.find(item => item.id === productId);
      
      if (existingItem) {
        return {
          ...prev,
          cartItems: prev.cartItems.map(item =>
            item.id === productId
              ? { ...item, quantity: item.quantity + quantity }
              : item
          ),
        };
      }

      return {
        ...prev,
        cartItems: [
          ...prev.cartItems,
          {
            id: product.id,
            name: product.name,
            price: product.price,
            quantity,
          },
        ],
      };
    });
  };

  const removeFromCart = (productId: number) => {
    logEvent('remove_from_cart', { productId });

    setState(prev => ({
      ...prev,
      cartItems: prev.cartItems.filter(item => item.id !== productId),
    }));
  };

  const updateCartQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }

    logEvent('update_cart_quantity', { productId, quantity });

    setState(prev => ({
      ...prev,
      cartItems: prev.cartItems.map(item =>
        item.id === productId ? { ...item, quantity } : item
      ),
    }));
  };

  const applyCoupon = (code: string): boolean => {
    const upperCode = code.toUpperCase();
    const discount = COUPONS[upperCode];

    logEvent('apply_coupon', { code: upperCode, success: !!discount });

    if (discount !== undefined) {
      setState(prev => ({
        ...prev,
        coupon: { code: upperCode, discountValue: discount },
      }));
      return true;
    }
    return false;
  };

  const removeCoupon = () => {
    logEvent('remove_coupon', { code: state.coupon?.code });

    setState(prev => ({
      ...prev,
      coupon: null,
    }));
  };

  const setPage = (page: StoreState['page']) => {
    logEvent('navigate', { from: state.page, to: page });

    setState(prev => ({
      ...prev,
      page,
    }));
  };

  const setSelectedProduct = (productId: number | null) => {
    setState(prev => ({
      ...prev,
      selectedProductId: productId,
    }));
  };

  const checkout = () => {
    if (BUG_CHECKOUT_DISABLED) {
      logEvent('checkout_blocked', { reason: 'bug_enabled' });
      return;
    }

    const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    logEvent('checkout_complete', { 
      orderNumber, 
      total: state.total,
      itemCount: state.cartItems.length,
    });

    setState(prev => ({
      ...prev,
      orderNumber,
      page: 'confirmation',
    }));
  };

  const reset = () => {
    logEvent('reset', {});
    setState(initialState);
  };

  // Expose API to window for Python control
  useEffect(() => {
    window.mockStoreAPI = {
      getState: () => state,
      reset,
      applyCoupon,
    };
  }, [state]);

  return (
    <StoreContext.Provider
      value={{
        state,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        applyCoupon,
        removeCoupon,
        setPage,
        setSelectedProduct,
        checkout,
        reset,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};
