import React from 'react';
import { useStore } from '../StoreContext';
import { CATEGORIES } from '../data';

export const Header: React.FC = () => {
  const { state, setPage } = useStore();

  const cartItemCount = state.cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="bg-indigo-600 text-white shadow-md" data-testid="header">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <h1 
              className="text-2xl font-bold cursor-pointer"
              onClick={() => setPage('home')}
              data-testid="logo"
            >
              MockStore
            </h1>
            
            <nav className="hidden md:flex space-x-4">
              {CATEGORIES.map(category => (
                <button
                  key={category}
                  className="hover:text-indigo-200 transition"
                  data-testid={`category-${category.toLowerCase()}`}
                  onClick={() => setPage('home')}
                >
                  {category}
                </button>
              ))}
            </nav>
          </div>

          <div className="flex items-center space-x-6">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products..."
                className="px-4 py-2 rounded text-gray-800 w-64"
                data-testid="search-input"
              />
            </div>

            <button
              className="relative hover:text-indigo-200 transition"
              onClick={() => setPage('cart')}
              data-testid="cart-button"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
                />
              </svg>
              {cartItemCount > 0 && (
                <span
                  className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center"
                  data-testid="cart-count"
                >
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
