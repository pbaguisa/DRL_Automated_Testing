# Web DRL E-Commerce Testing Framework

A Deep Reinforcement Learning (DRL) framework for automated testing and validation of web e-commerce applications. This project uses Playwright-controlled browser automation combined with DRL agents (PPO/A2C) to explore and test web application behavior.

## 🏗️ Architecture

This project mirrors the structure of a Pygame-based DRL testing framework but targets web applications:

```
web_drl_project/
├── web_app/              # React + TypeScript e-commerce site
│   ├── src/
│   │   ├── components/   # Header, Footer, TestHUD
│   │   ├── pages/        # Home, PDP, Cart, Confirmation
│   │   ├── StoreContext.tsx
│   │   ├── types.ts
│   │   └── data.ts
│   ├── dist/             # Built static site (generated)
│   └── package.json
│
├── envs/web/             # Python Gymnasium environment
│   ├── __init__.py
│   └── web_shop_env.py   # Playwright-based env
│
├── src/                  # Training, eval, visualization
│   ├── train_web.py
│   ├── eval_web.py
│   └── visualize_web.py
│
├── configs/              # YAML configs
│   ├── ppo.yaml
│   ├── a2c.yaml
│   └── reward_modes.yaml
│
├── logs/                 # Training logs, CSVs, TensorBoard
├── models/               # Saved trained agents
├── requirements.txt
└── README.md
```

## 🚀 Setup

### 1. Build the Web App

```bash
cd web_app
npm install  # or pnpm install
npm run build
```

This creates a static build in `web_app/dist/`.

### 2. Install Python Dependencies

```bash
# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install Playwright browsers
playwright install chromium
```

## 🎮 Web Application

The web app is a deterministic, frontend-only mock e-commerce store with:

- **Pages**: Home (catalog), Product Detail, Cart, Checkout Modal, Confirmation
- **Features**: Add to cart, apply coupons, checkout flow
- **Instrumentation**: All elements have `data-testid` attributes for Playwright
- **Global API**: `window.mockStoreAPI` exposes state for Python control
- **Test HUD**: Overlay showing state (cart, totals, coupons, order number)
- **Bug Simulation**: URL params (`?bugSubtotalMismatch=1`, etc.)

### Coupons

- `SAVE10` - $10 off
- `SAVE20` - $20 off
- `WELCOME15` - $15 off
- `HOLIDAY25` - $25 off

### Products

8 tech products ranging from $49.99 to $2,199.99 across categories (Laptops, Monitors, Accessories, etc.)

## 🤖 DRL Environment

**Observation Space** (8 features):
- Page (0=home, 1=pdp, 2=cart, 3=checkout, 4=confirmation)
- Cart items count
- Subtotal (normalized)
- Tax (normalized)
- Shipping (normalized)
- Total (normalized)
- Has coupon (binary)
- Order complete (binary)

**Action Space** (18 discrete actions):
- 0: Navigate to home
- 1-8: Click products 1-8
- 9: Add to cart (on PDP)
- 10: Go to cart
- 11-14: Apply coupons (SAVE10, SAVE20, WELCOME15, HOLIDAY25)
- 15: Proceed to checkout
- 16: Confirm order
- 17: No-op

**Reward Modes (Personas)**:

1. **Shopper**: Optimizes for quick, valid checkout
   - +5 for adding items
   - +10 for progressing in checkout
   - +100 for completing order
   - +15 for applying coupon
   - -0.5 per step (efficiency penalty)

2. **Validator**: Focuses on testing and bug detection
   - +2 for testing coupons
   - +3 for cart operations
   - +50 for detecting price mismatches
   - +30 for completing validation
   - -0.3 per step

## 📚 Usage

### Training

Train a PPO agent with the "shopper" persona:

```bash
python src/train_web.py --algo=ppo --persona=shopper --seed=1 --timesteps=50000
```

Train an A2C agent with the "validator" persona:

```bash
python src/train_web.py --algo=a2c --persona=validator --seed=1 --timesteps=50000
```

**Arguments**:
- `--algo`: Algorithm (ppo or a2c)
- `--persona`: Reward mode (shopper or validator)
- `--seed`: Random seed for reproducibility
- `--timesteps`: Total training timesteps
- `--config`: Path to config YAML (optional)

### Evaluation

Evaluate a trained model:

```bash
python src/eval_web.py --model=models/ppo_web_shopper_seed1 --algo=ppo --persona=shopper --episodes=10
```

With screenshots:

```bash
python src/eval_web.py --model=models/ppo_web_shopper_seed1 --algo=ppo --persona=shopper --episodes=5 --screenshots
```

**Arguments**:
- `--model`: Path to trained model (without .zip)
- `--algo`: Algorithm used
- `--persona`: Reward mode
- `--episodes`: Number of evaluation episodes
- `--seed`: Random seed
- `--screenshots`: Save screenshots during evaluation

### Visualization

Watch a trained agent in action (visible browser):

```bash
python src/visualize_web.py --model=models/ppo_web_shopper_seed1 --algo=ppo --persona=shopper --delay=1.5
```

**Arguments**:
- `--model`: Path to trained model
- `--algo`: Algorithm used
- `--persona`: Reward mode
- `--episodes`: Number of episodes to visualize
- `--delay`: Delay between actions (seconds)

## 📊 Logs and Metrics

Training logs are saved to:
```
logs/
├── ppo_web_shopper_seed1/
│   ├── PPO_1/                   # TensorBoard logs
│   ├── ppo_checkpoint_*.zip     # Checkpoints
│   └── training_metadata.yaml
│
└── eval_ppo_shopper_seed1_TIMESTAMP.csv
```

View TensorBoard:
```bash
tensorboard --logdir=logs
```

## 🧪 Testing Bug Detection

Enable bug simulation in the web app:

```bash
# Modify the app URL in web_shop_env.py or pass as parameter
# Example: file:///path/to/dist/index.html?bugSubtotalMismatch=1
```

Train a validator agent to detect bugs:

```bash
python src/train_web.py --algo=ppo --persona=validator --seed=1
```

The validator persona rewards detecting price mismatches and anomalies.

## 🔬 Reproducibility

All experiments are fully reproducible:

1. **Fixed seeds**: Set via `--seed` parameter
2. **Deterministic environment**: Web app has no randomness
3. **Pinned dependencies**: `requirements.txt` locks versions
4. **Config files**: All hyperparameters in YAML

Example reproducible run:

```bash
# Training
python src/train_web.py --algo=ppo --persona=shopper --seed=7 --timesteps=50000

# Evaluation
python src/eval_web.py --model=models/ppo_web_shopper_seed7 --algo=ppo --persona=shopper --seed=7 --episodes=20
```

## 📈 Comparing Algorithms & Personas

Train multiple configurations:

```bash
# PPO Shopper
python src/train_web.py --algo=ppo --persona=shopper --seed=1

# PPO Validator
python src/train_web.py --algo=ppo --persona=validator --seed=1

# A2C Shopper
python src/train_web.py --algo=a2c --persona=shopper --seed=1

# A2C Validator
python src/train_web.py --algo=a2c --persona=validator --seed=1
```

Evaluate and compare:

```bash
python src/eval_web.py --model=models/ppo_web_shopper_seed1 --algo=ppo --persona=shopper --episodes=20
python src/eval_web.py --model=models/ppo_web_validator_seed1 --algo=ppo --persona=validator --episodes=20
python src/eval_web.py --model=models/a2c_web_shopper_seed1 --algo=a2c --persona=shopper --episodes=20
python src/eval_web.py --model=models/a2c_web_validator_seed1 --algo=a2c --persona=validator --episodes=20
```

Results are saved as CSV files in `logs/` for analysis.

## 🎯 Use Cases

1. **Automated E-Commerce Testing**: Train agents to explore checkout flows
2. **Bug Detection**: Use validator persona to find edge cases and bugs
3. **Load Testing**: Run multiple agents in parallel
4. **UI/UX Analysis**: Identify confusing navigation patterns
5. **Regression Testing**: Compare agent behavior across app versions

## 🔧 Customization

### Adding New Products

Edit `web_app/src/data.ts`:

```typescript
export const PRODUCTS: Product[] = [
  {
    id: 9,
    name: 'New Product',
    price: 99.99,
    description: 'Product description',
    category: 'Category',
    image: 'https://via.placeholder.com/300x200',
    stock: 20,
  },
  // ...
];
```

Rebuild the app: `npm run build`

### Adding New Actions

1. Update action space in `envs/web/web_shop_env.py`
2. Add action execution logic in `_execute_action()`
3. Update action names in `visualize_web.py`

### Custom Reward Functions

Edit `_calculate_reward()` in `envs/web/web_shop_env.py`:

```python
elif self.reward_mode == "my_custom_mode":
    # Custom reward logic
    if some_condition:
        reward += 50.0
    # ...
```

Add config in `configs/reward_modes.yaml`.

## 🐛 Troubleshooting

**Issue**: Playwright browser doesn't launch
```bash
playwright install chromium
```

**Issue**: Can't find web app
- Ensure `web_app/dist/` exists: `npm run build`
- Check path in `web_shop_env.py`

**Issue**: Training is slow
- Reduce `--timesteps`
- Use fewer `n_steps` in config
- Train with `headless=True` (default)

**Issue**: Agent gets stuck
- Tune reward function
- Increase exploration (`ent_coef`)
- Try different seed

## 📝 License

This is a research/educational project for DRL testing frameworks.

## 🙏 Acknowledgments

- Stable-Baselines3 for DRL algorithms
- Playwright for browser automation
- Gymnasium for environment interface
- React + Vite for web framework

---

**Built as a parallel project to a Pygame DRL testing framework, demonstrating the same architectural patterns for web application testing.**
