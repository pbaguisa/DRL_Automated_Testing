import React, { useState } from 'react';
import { useStore } from '../StoreContext';

export const CartPage: React.FC = () => {
  const { state, updateCartQuantity, removeFromCart, applyCoupon, removeCoupon, setPage } = useStore();
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);

  const handleApplyCoupon = () => {
    const success = applyCoupon(couponInput);
    if (success) {
      setCouponInput('');
      setCouponError('');
    } else {
      setCouponError('Invalid coupon code');
    }
  };

  const handleCheckout = () => {
    setShowCheckoutModal(true);
  };

  return (
    <div className="container mx-auto px-4 py-8" data-testid="cart-page">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>

      {state.cartItems.length === 0 ? (
        <div className="text-center py-16" data-testid="empty-cart">
          <p className="text-gray-500 text-lg mb-4">Your cart is empty</p>
          <button
            onClick={() => setPage('home')}
            className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700"
            data-testid="continue-shopping"
          >
            Continue Shopping
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {state.cartItems.map(item => (
              <div
                key={item.id}
                className="bg-white rounded-lg shadow p-6 mb-4 flex items-center"
                data-testid={`cart-item-${item.id}`}
              >
                <div className="flex-1">
                  <h3 className="text-lg font-semibold mb-2" data-testid={`cart-item-name-${item.id}`}>
                    {item.name}
                  </h3>
                  <p className="text-gray-600" data-testid={`cart-item-price-${item.id}`}>
                    ${item.price.toFixed(2)} each
                  </p>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex items-center border rounded">
                    <button
                      onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                      className="px-3 py-1 hover:bg-gray-100"
                      data-testid={`cart-decrease-${item.id}`}
                    >
                      -
                    </button>
                    <span className="px-4 py-1" data-testid={`cart-quantity-${item.id}`}>
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                      className="px-3 py-1 hover:bg-gray-100"
                      data-testid={`cart-increase-${item.id}`}
                    >
                      +
                    </button>
                  </div>

                  <div className="font-semibold text-lg" data-testid={`cart-item-total-${item.id}`}>
                    ${(item.price * item.quantity).toFixed(2)}
                  </div>

                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="text-red-600 hover:text-red-800"
                    data-testid={`cart-remove-${item.id}`}
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div>
            <div className="bg-white rounded-lg shadow p-6" data-testid="cart-summary">
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between" data-testid="summary-subtotal">
                  <span>Subtotal:</span>
                  <span>${state.subtotal.toFixed(2)}</span>
                </div>

                {state.coupon && (
                  <div className="flex justify-between text-green-600" data-testid="summary-coupon">
                    <span>Coupon ({state.coupon.code}):</span>
                    <span>-${state.coupon.discountValue.toFixed(2)}</span>
                    <button
                      onClick={removeCoupon}
                      className="text-red-600 ml-2"
                      data-testid="remove-coupon-button"
                    >
                      ✕
                    </button>
                  </div>
                )}

                <div className="flex justify-between" data-testid="summary-tax">
                  <span>Tax (13%):</span>
                  <span>${state.tax.toFixed(2)}</span>
                </div>

                <div className="flex justify-between" data-testid="summary-shipping">
                  <span>Shipping:</span>
                  <span>{state.shipping === 0 ? 'FREE' : `$${state.shipping.toFixed(2)}`}</span>
                </div>

                <div className="border-t pt-2 mt-2">
                  <div className="flex justify-between text-xl font-bold" data-testid="summary-total">
                    <span>Total:</span>
                    <span>${state.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-semibold mb-2">Have a coupon?</label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    placeholder="Enter coupon code"
                    className="flex-1 border rounded px-3 py-2"
                    data-testid="coupon-input"
                  />
                  <button
                    onClick={handleApplyCoupon}
                    className="bg-gray-200 px-4 py-2 rounded hover:bg-gray-300"
                    data-testid="apply-coupon-button"
                  >
                    Apply
                  </button>
                </div>
                {couponError && (
                  <p className="text-red-600 text-sm mt-1" data-testid="coupon-error">
                    {couponError}
                  </p>
                )}
              </div>

              <button
                onClick={handleCheckout}
                className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700"
                data-testid="checkout-button"
              >
                Proceed to Checkout
              </button>
            </div>
          </div>
        </div>
      )}

      {showCheckoutModal && (
        <CheckoutModal onClose={() => setShowCheckoutModal(false)} />
      )}
    </div>
  );
};

const CheckoutModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { checkout } = useStore();
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    address: '',
    city: '',
    postalCode: '',
    cardNumber: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    checkout();
    onClose();
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
      data-testid="checkout-modal"
    >
      <div className="bg-white rounded-lg p-8 max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Checkout</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
            data-testid="close-checkout-modal"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-1">Email</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              className="w-full border rounded px-3 py-2"
              data-testid="checkout-email"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1">Full Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              className="w-full border rounded px-3 py-2"
              data-testid="checkout-name"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1">Address</label>
            <input
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              required
              className="w-full border rounded px-3 py-2"
              data-testid="checkout-address"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-1">City</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                required
                className="w-full border rounded px-3 py-2"
                data-testid="checkout-city"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1">Postal Code</label>
              <input
                type="text"
                value={formData.postalCode}
                onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                required
                className="w-full border rounded px-3 py-2"
                data-testid="checkout-postal"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1">Card Number</label>
            <input
              type="text"
              value={formData.cardNumber}
              onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
              required
              placeholder="1234 5678 9012 3456"
              className="w-full border rounded px-3 py-2"
              data-testid="checkout-card"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700"
            data-testid="confirm-order-button"
          >
            Confirm Order
          </button>
        </form>
      </div>
    </div>
  );
};
