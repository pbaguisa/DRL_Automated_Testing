# Comparison: Game DRL vs Web DRL Projects

This document shows how the web DRL project mirrors the game DRL project architecture.

## High-Level Architecture Comparison

### Game Project
```
game/
├── envs/game/bubble_game_env.py    # Pygame environment
├── src/train.py                    # Training script
├── src/eval.py                     # Evaluation script
├── src/visualize.py                # Visualization
├── logs/                           # Training logs
└── models/                         # Saved models
```

### Web Project
```
web_drl_project/
├── web_app/                        # React app (parallel to game binary)
├── envs/web/web_shop_env.py       # Playwright environment
├── src/train_web.py               # Training script
├── src/eval_web.py                # Evaluation script
├── src/visualize_web.py           # Visualization
├── logs/                          # Training logs
└── models/                        # Saved models
```

## Environment Comparison

| Aspect | Game Environment | Web Environment |
|--------|------------------|-----------------|
| **Base class** | `gymnasium.Env` | `gymnasium.Env` |
| **Rendering** | Pygame surface | Playwright browser |
| **Actions** | Discrete (movement, shoot) | Discrete (click, navigate) |
| **Observations** | Game state array | Web state array |
| **Reward modes** | speedrunner, survivor | shopper, validator |
| **Reset** | Reset game state | Reload browser page |
| **Step** | Game tick | Browser action |
| **Deterministic** | Fixed seed | Fixed seed + static content |

### Game Environment (Pygame)
```python
class BubbleGameEnv(gym.Env):
    def __init__(self, reward_mode='speedrunner', headless=True):
        # Pygame initialization
        self.action_space = spaces.Discrete(5)  # Up, down, left, right, shoot
        self.observation_space = spaces.Box(...)
    
    def step(self, action):
        # Update game state
        return obs, reward, terminated, truncated, info
```

### Web Environment (Playwright)
```python
class WebShopEnv(gym.Env):
    def __init__(self, reward_mode='shopper', headless=True):
        # Playwright initialization
        self.action_space = spaces.Discrete(18)  # Click, navigate, etc.
        self.observation_space = spaces.Box(...)
    
    def step(self, action):
        # Execute browser action
        return obs, reward, terminated, truncated, info
```

## Reward Modes (Personas) Comparison

### Game Personas
- **speedrunner**: Maximize speed, minimize time
- **survivor**: Maximize survival, avoid damage

### Web Personas
- **shopper**: Maximize checkout efficiency
- **validator**: Maximize bug detection

Both use the same pattern: Different reward functions for different objectives.

## Training Script Comparison

### Game Training
```python
# game/src/train.py
from envs.game.bubble_game_env import BubbleGameEnv

env = BubbleGameEnv(reward_mode='speedrunner', headless=True)
model = PPO("MlpPolicy", env, ...)
model.learn(total_timesteps=50000)
model.save("models/ppo_speedrunner_seed1")
```

### Web Training
```python
# web_drl_project/src/train_web.py
from envs.web.web_shop_env import WebShopEnv

env = WebShopEnv(reward_mode='shopper', headless=True)
model = PPO("MlpPolicy", env, ...)
model.learn(total_timesteps=50000)
model.save("models/ppo_web_shopper_seed1")
```

**Same structure, different environments!**

## Command-Line Interface Comparison

### Game Commands
```bash
# Training
python src/train.py --algo=ppo --reward_mode=speedrunner --seed=1

# Evaluation
python src/eval.py --algo=ppo --reward_mode=speedrunner --episodes=10

# Visualization
python src/visualize.py --algo=ppo --reward_mode=speedrunner
```

### Web Commands
```bash
# Training
python src/train_web.py --algo=ppo --persona=shopper --seed=1

# Evaluation
python src/eval_web.py --algo=ppo --persona=shopper --episodes=10

# Visualization
python src/visualize_web.py --algo=ppo --persona=shopper
```

**Nearly identical CLI patterns!**

## Configuration Files Comparison

### Game Configs
```
game/
├── configs/
│   ├── ppo.yaml
│   ├── a2c.yaml
│   └── reward_modes.yaml
```

### Web Configs
```
web_drl_project/
├── configs/
│   ├── ppo.yaml
│   ├── a2c.yaml
│   └── reward_modes.yaml
```

**Identical structure and format!**

## Logging and Metrics Comparison

### Game Logs
```
game/logs/
├── ppo_speedrunner_seed1/
│   ├── PPO_1/events.out.tfevents.*
│   └── training_metadata.yaml
└── eval_ppo_speedrunner_seed1.csv
```

### Web Logs
```
web_drl_project/logs/
├── ppo_web_shopper_seed1/
│   ├── PPO_1/events.out.tfevents.*
│   └── training_metadata.yaml
└── eval_ppo_web_shopper_seed1.csv
```

**Same logging structure!**

## Evaluation Metrics Comparison

### Game Metrics
- Episode reward
- Steps taken
- Enemies defeated
- Damage taken
- Success rate

### Web Metrics
- Episode reward
- Steps taken
- Cart operations
- Coupon attempts
- Checkout success rate

**Similar metric categories!**

## Key Differences

| Aspect | Game Project | Web Project |
|--------|--------------|-------------|
| **Binary/App** | Compiled Pygame | Built React app |
| **Startup** | Launch executable | Open browser + load page |
| **State access** | Direct game state | `window.mockStoreAPI` |
| **Rendering** | Game loop | Browser DOM |
| **Instrumentation** | Game variables | `data-testid` attributes |
| **Bug injection** | Code flags | URL parameters |
| **Demo mode** | Screen recording | Browser automation |

## Shared Design Patterns

1. **Separation of Concerns**
   - Environment (game/web)
   - Training logic
   - Evaluation logic
   - Visualization

2. **Reproducibility**
   - Fixed seeds
   - Config files
   - Pinned dependencies
   - Deterministic environments

3. **Modularity**
   - Pluggable reward modes
   - Swappable algorithms (PPO/A2C)
   - Independent components

4. **Observability**
   - TensorBoard integration
   - CSV logging
   - Detailed metrics
   - Debug overlays (HUD)

5. **Extensibility**
   - Easy to add personas
   - Easy to add actions
   - Easy to modify rewards

## Why This Structure Works

### ✅ Consistency
Both projects follow the same patterns, making it easy to understand and maintain.

### ✅ Modularity
Clear boundaries between components allow independent development.

### ✅ Reproducibility
Identical logging and configuration approaches ensure reproducible experiments.

### ✅ Scalability
Can easily add more environments (mobile app, desktop app, etc.) following the same pattern.

### ✅ Reusability
Training and evaluation scripts are nearly identical, minimizing code duplication.

## Migration Path

If you have experience with one project, migrating to the other is straightforward:

1. **Environment**: Replace `BubbleGameEnv` with `WebShopEnv` (or vice versa)
2. **Actions**: Adjust action space to match new environment
3. **Observations**: Adjust observation extraction
4. **Rewards**: Define new personas for new domain
5. **Everything else stays the same!**

## Example: Adding a New Persona

### Game Project
```python
# envs/game/bubble_game_env.py
elif self.reward_mode == "collector":
    # Reward collecting items
    reward = items_collected * 10
```

### Web Project
```python
# envs/web/web_shop_env.py
elif self.reward_mode == "explorer":
    # Reward exploring pages
    reward = unique_pages_visited * 5
```

**Same pattern, different domain!**

## Conclusion

The web DRL project is a **faithful architectural replica** of the game DRL project:

- ✅ Same directory structure
- ✅ Same training/eval/viz scripts
- ✅ Same config system
- ✅ Same logging approach
- ✅ Same CLI patterns
- ✅ Same reproducibility measures

**The only difference is the environment being tested: Pygame game vs React web app.**

This demonstrates that the DRL testing framework architecture is **domain-agnostic** and can be applied to any testable system.

---

**Both projects prove that a consistent, modular architecture enables rapid development and testing across different domains.**
